﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2 {
	class Program {
		private static string LOGIC = "(CLAW + (DASH | SUPERDASH | WINGS | ((FIREBALL | SCREAM) + FIREBALLSKIPS))) | (WINGS + (DASH | ((FIREBALL | SCREAM) + FIREBALLSKIPS)) + SPIKETUNNELS + SHADESKIPS)";
		//private static string LOGIC = "A | B + (C + (B | D)) + E | F + G | H";

		private static Dictionary<string, bool> TARGET = new Dictionary<string, bool> {
			{ "SHADESKIPS", true },
			{ "ACIDSKIPS", true },
			{ "SPIKETUNNELS", true },
			{ "MISCSKIPS", true },
			{ "FIREBALLSKIPS", true },
			{ "MAGSKIPS", true },
		};

		private static Dictionary<string, bool> LOADOUT = new Dictionary<string, bool> {
			{ "CLAW", false },
			{ "DASH", true },
			{ "FIREBALL", true },
			{ "SCREAM", false },
			{ "SUPERDASH", false },
			{ "WINGS", true },
		};

		private static string GetValue( string op ) {

			//return op;

			foreach ( string key in LOADOUT.Keys ) {
				if ( op == key ) {
					if ( LOADOUT[key] ) {
						return "t";
					} else {
						return "f";
					}
				}
			}

			foreach ( string key in TARGET.Keys ) {
				if ( op == key ) {
					return TARGET[key] ? op : "f";
				}
			}

			throw new Exception( "UNKNOWN KEY IN LOGIC STRING: " + op );
		}

		static void Main( string[] args ) {
			string infix = LOGIC;

			Console.WriteLine( LOGIC );
			List<string> values = ShuntingYard( infix ).ToList();

			//if ( false ) {
			Dictionary<string, List<string>> temp = new Dictionary<string, List<string>>();

				int evalCount = 0;
				int nextOp = GetFirstOpIndex( values );

				Console.WriteLine( string.Join( " ", values.ToArray() ) );
				do {
					Console.WriteLine( "-----------" );
					Console.WriteLine( "Iteration " + evalCount );
					//Console.ReadLine();
					values = Eval( values, nextOp, ref temp );
					Console.WriteLine( string.Join( " ", values.ToArray() ) );
					DictDump( temp );

					nextOp = GetFirstOpIndex( values );
					evalCount++;
				} while ( nextOp != -1 );

				values = Simplify( values, ref temp );

				Console.WriteLine( "-------------------------" );
				Console.WriteLine( "RESULT: " + string.Join( " ", values.ToArray() ) );
			//}

			List<string> postfix1 = values;
			values = ShuntingYardInverse( values.ToArray() ).ToList();
			List<string> infix1 = values;
			List<string> postfix2 = ShuntingYard( string.Join( " ", infix1.ToArray() ) ).ToList();
			List<string> infix2 = ShuntingYardInverse( postfix2.ToArray() ).ToList();
			List<string> postfix3 = ShuntingYard( string.Join( " ", infix2.ToArray() ) ).ToList();
			List<string> infix3 = ShuntingYardInverse( postfix3.ToArray() ).ToList();

			Console.WriteLine( "-------------------------" );
			Console.WriteLine( "PFIX1: " + string.Join( " ", postfix1.ToArray() ) );
			Console.WriteLine( "IFIX1: " + string.Join( " ", infix1.ToArray() ) );

			Console.ReadLine();
		}

		private static List<string> Simplify( List<string> values, ref Dictionary<string, List<string>> temp ) {
			bool flattened = false;
			Console.WriteLine( "-----------" );
			Console.WriteLine( "SIMPLIFY:" );

			while ( flattened == false ) {
				flattened = true;
				Console.WriteLine( string.Join( " ", values.ToArray() ) );
				List<string> newValues = new List<string>();
				foreach ( string val in values ) {
					if ( IsTemp( val ) ) {
						newValues.AddRange( temp[val] );
						flattened = false;
					} else {
						newValues.Add(val);
					}
				}
				values = newValues;
			}

			return values;
		}

		private static void DictDump( Dictionary<string, List<string>> dict ) {
			if ( dict.Count > 0 ) {
				foreach ( string key in dict.Keys ) {
					Console.WriteLine( key + " = " + string.Join(" ", dict[key].ToArray()) );
				}
			}
		}

		private static List<string> Eval( List<string> values, int index, ref Dictionary<string, List<string>> dict ) {
			string arg1 = values[index - 2];
			string arg2 = values[index - 1];
			string op = values[index];
			string result = "";

			Console.WriteLine( "Eval: " + arg1 + ' ' + arg2 + ' ' + op );

			if ( IsTarget( arg1 ) || IsTarget( arg2 ) ) {
				if ( IsTarget( arg1 ) && IsTarget( arg2 ) ) {
					string tempName = "_" + dict.Count;
					dict.Add( tempName, new List<string> { arg1, arg2, op } );
					result = tempName;
				} else if ( arg1 == "f" || arg2 == "f" ) {
					if ( op == "+" ) {
						result = "f";
					} else { //Op must be "|"
						result = arg1 == "f" ? arg2 : arg1; //Get the other arg
					}
				} else { //One arg must be "t"
					if ( op == "+" ) {
						result = arg1 == "t" ? arg2 : arg1; //Get the other arg
					} else { //Op must be "|"
						result = "t";
					}
				}
			} else { //No special cases
				if ( op == "+" ) {
					result = (arg1 == "t" && arg2 == "t") ? "t" : "f";
				} else { //Op must be "|"
					result = ( arg1 == "f" && arg2 == "f" ) ? "f" : "t";
				}
			}

			Console.WriteLine( "Result: " + result );

			values[index] = result;
			values.RemoveAt( index - 1 );
			values.RemoveAt( index - 2 );

			return values;
		}

		private static bool IsTemp( string op ) {
			if ( op.StartsWith( "_" ) )
				return true;
			return false;
		}

		private static bool IsTarget( string op ) {
			if ( IsTemp( op ) )
				return true;

			foreach ( string key in TARGET.Keys ) {
				if ( op == key ) {
					return TARGET[key];
				}
			}

			return false;
		}

		private static int GetFirstOpIndex( List<string> values ) {
			for ( int i = 0; i < values.Count; i++ ) {
				if ( values[i] == "+" || values[i] == "|" ) {
					return i;
				}
			}
			return -1;
		}

		private static string[] ShuntingYardInverse( string[] postfix ) {
			Stack<string> stack = new Stack<string>();
			List<string> infix = new List<string>();

			Console.WriteLine( string.Join(" ", postfix) );
			for ( int i = 0; i < postfix.Length; i++ ) {
				string sym = postfix[i];
				Console.WriteLine( i + " Sym: " + sym );

				if ( sym == "+" || sym == "|" ) {
					string arg1 = stack.Pop();
					string arg2 = stack.Pop();
					stack.Push( "( " + arg1 + " " + sym + " " + arg2 + " )" );
				} else {
					stack.Push( sym );
				}

				Console.WriteLine( i + " Stack: " + string.Join(" ", stack.ToArray()) );
			}

			infix = TrimParentheses( stack.Pop().Split(' ').ToList() );

			return infix.ToArray();
		}

		private static List<string> TrimParentheses( List<string> infix ) {
			Func<List<string>, int, int> getMatchingParens = ( @in, start ) => {
				int count = 0;
				for ( int i = start; i < @in.Count; i++ ) {
					if ( @in[i] == "(" ) {
						count++;
						continue;
					}

					if ( @in[i] == ")" ) {
						count--;
						if ( count == 0 ) {
							return i;
						}
						continue;
					}
					
					continue;
				}

				throw new Exception( "Couldn't find a matching parens!" );
			};

			Func<List<string>, int, bool, string> findNearestOp = ( prmIn, prmStart, prmForward ) => {
				int i = prmStart;
				while ( true ) {
					if ( prmForward ) {
						i++;
						if ( i >= prmIn.Count ) {
							return string.Empty;
						}
					} else {
						i--;
						if ( i < 0 ) {
							return string.Empty;
						}
					}

					string sym = prmIn[i];
					if ( sym == "(" || sym == ")" ) {
						return string.Empty;
					}

					if ( sym == "+" || sym == "|" ) {
						return prmIn[i];
					}
				}
			};

			Func<string, int> getOpPriority = ( sym ) => {
				switch ( sym ) {
					case "(":
					case ")":
						return 0;
					case "+":
						return 2;
					case "|":
						return 1;
					default:
						return -1;
				}
			};

			Func<string, string, string, bool> isRedundant = ( pL, pLow, pR ) => {
				int lowPri = getOpPriority( pLow );
				if ( lowPri < getOpPriority( pL ) || lowPri < getOpPriority( pR ) ) {
					return false;
				}
				return true;
			};

			List<string> newInfix = new List<string>();

			for ( int i = 0; i < infix.Count; i++ ) {
				Console.WriteLine( string.Join( " ", infix.ToArray() ) );
				//Console.WriteLine( i + "|" + infix.Count + "|" + infix[i] );
				if ( infix[i] != "(" ) {
					newInfix.Add( infix[i] );
					continue;
				}

				int j = getMatchingParens( infix, i );

				string L = findNearestOp( infix, i, false );
				string low = string.Empty;
				if ( i + 1 != j ) {
					for ( int k = i + 1; k < j; k++ ) {
						string sym = infix[k];
						if ( sym == "(" ) {
							k = getMatchingParens( infix, k );
							continue;
						}
						if ( sym == "|" || sym == "+" ) {
							if ( sym == "|" ) {
								low = sym;
								break;  //Lowest priority op possible...
							} else if ( sym == "+" && low == string.Empty ) {
								low = sym;
								continue;
							}
						}
					}
				}
				string R = findNearestOp( infix, j, true );

				Console.WriteLine( L + "-" + i + "-" + low + "-" + j + "-" + R );

				if ( isRedundant(L, low, R) ) {
					//We can remove these parentheses.
					infix.RemoveAt( j );
					infix.RemoveAt( i );
					i--;
					continue;
				}
			}

			return infix;
		}

		public static string[] ShuntingYard( string infix ) {
			int i = 0;
			Stack<string> stack = new Stack<string>();
			List<string> postfix = new List<string>();

			while ( i < infix.Length ) {
				string sym = GetNextSymbol( infix, ref i );

				// Easiest way to deal with whitespace between operators
				if ( sym.Trim( ' ' ) == string.Empty ) {
					continue;
				}

				//Order of Operations:  "+" > "|"
				if ( sym == "+" || sym == "|" ) {
					while ( stack.Count != 0 && ( sym == "|" || ( sym == "+" && stack.Peek() != "|" ) ) && stack.Peek() != "(" ) {
						postfix.Add( stack.Pop() );
					}

					stack.Push( sym );
				} else if ( sym == "(" ) {
					stack.Push( sym );
				} else if ( sym == ")" ) {
					while ( stack.Peek() != "(" ) {
						postfix.Add( stack.Pop() );
					}

					stack.Pop();
				} else {
					postfix.Add( GetValue(sym) );
				}
			}

			while ( stack.Count != 0 ) {
				postfix.Add( stack.Pop() );
			}

			return postfix.ToArray();
		}

		private static string GetNextSymbol( string infix, ref int i ) {
			int start = i;

			if ( infix[i] == '(' || infix[i] == ')' || infix[i] == '+' || infix[i] == '|' ) {
				i++;
				return infix[i - 1].ToString();
			}

			while ( i < infix.Length && infix[i] != '(' && infix[i] != ')' && infix[i] != '+' && infix[i] != '|' ) {
				i++;
			}

			return infix.Substring( start, i - start ).Trim( ' ' );
		}
	}
}
